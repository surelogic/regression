package test;

import java.util.concurrent.locks.Lock;

public class NoModels {
	private final Lock lock1 = null;
	private final Lock lock2 = null;
	
	
}
