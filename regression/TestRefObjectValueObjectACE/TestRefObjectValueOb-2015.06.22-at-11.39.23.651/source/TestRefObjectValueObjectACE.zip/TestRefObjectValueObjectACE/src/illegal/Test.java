package illegal;

import com.surelogic.ReferenceObject;
import com.surelogic.ValueObject;

// Illegal combination
@ReferenceObject
@ValueObject
public class Test {

}
