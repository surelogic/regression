package com.surelogic.jsure.draw;

import com.surelogic.*;

//@Utility
public class DrawingHelper {
	/*
	private DrawingHelper() {
		// singleton
	}
	*/
	public static void drawSquare(Point at, int width) {
		Shape square = new Rectangle(at, width, width);
		Canvas.getInstance().addShape(square);
	}

	public static void drawRectangle(Point at, int width, int height) {
		Shape square = new Rectangle(at, width, height);
		Canvas.getInstance().addShape(square);
	}

	public static void drawPoint(int x, int y) {
		Canvas.getInstance().addPoint(Point.getInstance(x, y));
	}
}
