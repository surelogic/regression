package com.surelogic.jsure.draw;

import java.util.ArrayList;
import java.util.List;
import com.surelogic.*;

//@ThreadSafe
//@Immutable
public class Rectangle implements Shape {

	private final Point topLeft;
	private final int width, height;

	public Rectangle(Point topLeft, int width, int height) {
		if (topLeft == null || width < 1 || height < 1)
			throw new IllegalArgumentException();
		this.topLeft = topLeft;
		this.width = width;
		this.height = height;
	}

	public Point getTopLeft() {
		return topLeft;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public List<Point> getBounds() {
		final ArrayList<Point> result = new ArrayList<Point>();
		result.add(topLeft);
		result.add(Point.getInstance(topLeft, width, 0));
		result.add(Point.getInstance(topLeft, width, -height));
		result.add(Point.getInstance(topLeft, 0, -height));
		return null;
	}

	public List<Point> getOutline() {
		return getBounds();
	}
}
