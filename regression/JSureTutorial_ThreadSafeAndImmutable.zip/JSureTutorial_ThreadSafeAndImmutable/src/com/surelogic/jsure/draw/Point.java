package com.surelogic.jsure.draw;

import com.surelogic.*;
import java.util.ArrayList;
import java.util.List;

//@Immutable(appliesTo=Part.Instance)
//@ThreadSafe(appliesTo=Part.Static)
//@Region("static private FlyweightState")
//@RegionLock("FlyweightLock is INSTANCES protects FlyweightState")
public class Point {

	/*final*/ int x, y;

	private Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	//@UniqueInRegion("FlyweightState")
	private static /*final*/ List<Point> INSTANCES = new ArrayList<Point>();

	public static Point getInstance(int x, int y) {
		synchronized (INSTANCES) {
			for (Point p : INSTANCES) {
				if (p.x == x && p.y == y)
					return p;
			}
			final Point result = new Point(x, y);
			INSTANCES.add(result);
			return result;
		}
	}

	public static Point getInstance(Point from, int xOffset, int yOffset) {
		return getInstance(from.x + xOffset, from.y + yOffset);
	}
}
