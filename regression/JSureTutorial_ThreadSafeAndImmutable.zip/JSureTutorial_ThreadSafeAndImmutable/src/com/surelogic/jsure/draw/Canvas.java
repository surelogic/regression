package com.surelogic.jsure.draw;

import com.surelogic.*;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

//@ThreadSafe
//@Singleton
public final class Canvas {

	private final Set<Point> points = new CopyOnWriteArraySet<Point>();

	public void addPoint(Point value) {
		if (value != null)
			points.add(value);
	}

	private final List<Shape> shapes = new CopyOnWriteArrayList<Shape>();

	public void addShape(Shape value) {
		if (value != null)
			shapes.add(value);
	}

	public static Canvas getInstance() {
		return INSTANCE;
	}

	private static final Canvas INSTANCE = new Canvas();

	private Canvas() {
		// singleton
	}
}
