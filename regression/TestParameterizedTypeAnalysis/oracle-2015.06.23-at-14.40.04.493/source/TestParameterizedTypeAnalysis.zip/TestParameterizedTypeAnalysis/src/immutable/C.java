package immutable;

import com.surelogic.AnnotationBounds;

@AnnotationBounds(immutable="X")
public class C<X> {
  // falala
}
