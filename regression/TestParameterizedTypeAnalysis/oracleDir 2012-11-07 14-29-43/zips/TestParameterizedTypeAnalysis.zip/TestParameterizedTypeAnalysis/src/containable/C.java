package containable;

import com.surelogic.AnnotationBounds;

@AnnotationBounds(containable="X")
public class C<X> {
  // falala
}
