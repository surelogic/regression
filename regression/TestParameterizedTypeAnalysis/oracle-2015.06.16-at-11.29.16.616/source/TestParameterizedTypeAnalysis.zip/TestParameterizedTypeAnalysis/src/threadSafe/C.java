package threadSafe;

import com.surelogic.AnnotationBounds;

@AnnotationBounds(threadSafe="X")
public class C<X> {
  // falala
}
