package valObject.testAnnotationDecls;

import com.surelogic.ValueObject;

@ValueObject
public @interface Empty {
}
