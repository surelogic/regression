package containable.testAnnotationDecls;

import com.surelogic.Containable;

@Containable
public interface Empty {
}
