package threadSafe.testClasses;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class Empty {

}
