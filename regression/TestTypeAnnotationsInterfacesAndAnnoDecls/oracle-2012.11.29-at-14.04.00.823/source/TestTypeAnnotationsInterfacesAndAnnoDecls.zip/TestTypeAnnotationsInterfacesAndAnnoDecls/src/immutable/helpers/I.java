package immutable.helpers;

import com.surelogic.Immutable;

@Immutable
public class I {
  // who cares
}
