package valObject.testInterfaces;

import com.surelogic.ValueObject;

@ValueObject
public interface T {
  @Override
  public boolean equals(Object o);
}
