package threadSafe.testAnnotationDecls;

import com.surelogic.ThreadSafe;

@ThreadSafe
public @interface Empty {

}
