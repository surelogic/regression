package immutable.testClasses;

import com.surelogic.Immutable;

@Immutable
public class Empty {

}
