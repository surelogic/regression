package immutable.testAnnotationDecls;

import com.surelogic.Immutable;

@Immutable
public @interface Empty {

}
