package immutable.testInterfaces;

import com.surelogic.Immutable;

@Immutable
public interface Empty {

}
