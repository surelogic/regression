package immutable.helpers;

public class Other {
  // who cares
}
