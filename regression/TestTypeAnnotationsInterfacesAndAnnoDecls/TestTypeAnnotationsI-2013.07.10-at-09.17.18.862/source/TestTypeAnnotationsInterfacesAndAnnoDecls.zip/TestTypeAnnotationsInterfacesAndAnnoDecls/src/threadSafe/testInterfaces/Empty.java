package threadSafe.testInterfaces;

import com.surelogic.ThreadSafe;

@ThreadSafe
public interface Empty {

}
