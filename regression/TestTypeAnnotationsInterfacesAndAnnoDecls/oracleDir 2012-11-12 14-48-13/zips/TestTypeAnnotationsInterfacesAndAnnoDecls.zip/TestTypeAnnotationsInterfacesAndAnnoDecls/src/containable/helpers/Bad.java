package containable.helpers;

public class Bad {
  // foo
}