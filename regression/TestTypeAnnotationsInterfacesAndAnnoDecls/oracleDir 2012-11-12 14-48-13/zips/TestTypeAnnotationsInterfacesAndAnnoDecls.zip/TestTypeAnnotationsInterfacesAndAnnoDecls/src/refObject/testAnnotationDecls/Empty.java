package refObject.testAnnotationDecls;

import com.surelogic.ReferenceObject;

@ReferenceObject
public @interface Empty {
}
