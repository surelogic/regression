package immutable.helpers;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class TS {
  // who cares
}
