package containable.testInterfaces;

import com.surelogic.Containable;

@Containable // modeling problem
public @interface Empty {
}
