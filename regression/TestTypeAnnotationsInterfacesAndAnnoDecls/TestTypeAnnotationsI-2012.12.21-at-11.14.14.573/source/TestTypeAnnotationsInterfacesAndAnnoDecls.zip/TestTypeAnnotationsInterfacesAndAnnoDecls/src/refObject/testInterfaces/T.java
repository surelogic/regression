package refObject.testInterfaces;

import com.surelogic.ReferenceObject;

@ReferenceObject
public interface T {
  @Override
  public boolean equals(Object o);
}
