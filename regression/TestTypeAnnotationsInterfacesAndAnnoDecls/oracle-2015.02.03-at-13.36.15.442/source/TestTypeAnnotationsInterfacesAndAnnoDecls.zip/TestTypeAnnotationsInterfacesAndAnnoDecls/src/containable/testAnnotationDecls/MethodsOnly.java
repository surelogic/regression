package containable.testAnnotationDecls;

import com.surelogic.Containable;

@Containable
public interface MethodsOnly {
  public void m();
  public void n();
}
