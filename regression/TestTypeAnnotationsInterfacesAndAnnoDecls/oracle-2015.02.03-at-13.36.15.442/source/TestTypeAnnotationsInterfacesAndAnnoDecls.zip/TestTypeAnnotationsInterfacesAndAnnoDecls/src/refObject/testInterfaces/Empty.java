package refObject.testInterfaces;

import com.surelogic.ReferenceObject;

@ReferenceObject
public interface Empty {
}
