package test.effects;

import com.surelogic.*;

@Region("Foo")
public class Effects {
	@InRegion("Foo")
	int foo;
	
	@RegionEffects("reads Foo")
	int foo() {
		return foo;
	}
}
