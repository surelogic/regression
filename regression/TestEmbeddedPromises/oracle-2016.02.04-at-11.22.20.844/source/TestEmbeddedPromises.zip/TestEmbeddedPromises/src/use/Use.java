package use;

import usingAnnos.Test2;
import usingPromises.Test;

public class Use {
	Test test;
	Test2 test2;
}
