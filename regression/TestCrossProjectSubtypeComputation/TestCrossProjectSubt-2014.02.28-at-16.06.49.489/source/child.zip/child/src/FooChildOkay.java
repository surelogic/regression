import com.surelogic.ThreadSafe;


@ThreadSafe
public class FooChildOkay {

}
