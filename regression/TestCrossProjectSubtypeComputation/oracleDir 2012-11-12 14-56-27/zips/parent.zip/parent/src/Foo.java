import com.surelogic.ThreadSafe;

@ThreadSafe
public class Foo {

}
