
public class FooChild2 extends Foo {

}
