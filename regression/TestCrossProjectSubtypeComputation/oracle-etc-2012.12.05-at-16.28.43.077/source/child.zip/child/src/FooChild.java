
public class FooChild extends Foo {

}
