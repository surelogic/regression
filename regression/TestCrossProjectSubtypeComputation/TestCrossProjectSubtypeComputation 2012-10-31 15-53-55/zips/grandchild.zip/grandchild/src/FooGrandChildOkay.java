public class FooGrandChildOkay extends FooChildOkay {

}
