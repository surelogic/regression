package test;

// do not propose to make this @Containable
enum MyEnum { A, B, C; }
