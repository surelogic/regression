package test;

import com.surelogic.Utility;

@Utility
public interface I {

}
