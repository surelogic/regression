package test;

import com.surelogic.Utility;

@Utility
public class U {
  private U() {
    super();
  }
}
