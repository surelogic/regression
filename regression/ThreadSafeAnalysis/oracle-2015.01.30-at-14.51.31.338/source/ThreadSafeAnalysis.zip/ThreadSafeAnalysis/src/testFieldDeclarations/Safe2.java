package testFieldDeclarations;

import com.surelogic.Immutable;

@Immutable
public class Safe2 {
	// Trivially safe: no state
}
