package testSanityChecks;

import com.surelogic.ThreadSafe;

/* Good: Extends java.lang.Object */
@ThreadSafe
class A {
}