package testFieldDeclarations;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class Safe {
	// Trivially safe: no state
}
