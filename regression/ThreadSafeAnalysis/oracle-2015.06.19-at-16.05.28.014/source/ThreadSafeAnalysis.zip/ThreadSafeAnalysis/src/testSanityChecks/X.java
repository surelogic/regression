package testSanityChecks;

class X {
  // not thread safe
}