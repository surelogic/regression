package testSanityChecks;

import com.surelogic.ThreadSafe;

/* Good, extends a class annotated with @ThreadSafe */
@ThreadSafe
class B extends A {
}