package testFieldDeclarations;

public class NotSafe {
  // empty
}
