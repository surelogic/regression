package valueObject;

import com.surelogic.ValueObject;

@ValueObject
public class RealClass {
  @ValueObject
  public class NestedClass {
    
  }
}
