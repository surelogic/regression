package immutable;

import com.surelogic.Immutable;

@Immutable
public class RealClass {
  @Immutable
  public class NestedClass {
    
  }
}
