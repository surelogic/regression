package referenceObject;

import com.surelogic.ReferenceObject;

@ReferenceObject
public class RealClass {
  @ReferenceObject
  public class NestedClass {
    
  }
}
