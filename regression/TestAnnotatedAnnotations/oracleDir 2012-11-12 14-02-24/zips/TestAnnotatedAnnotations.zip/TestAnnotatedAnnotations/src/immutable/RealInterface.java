package immutable;

import com.surelogic.Immutable;

@Immutable
public interface RealInterface {
  @Immutable
  public interface NestedInterface {
    
  }
}
