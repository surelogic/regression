package referenceObject;

import com.surelogic.ReferenceObject;

@ReferenceObject
public interface RealInterface {
  @ReferenceObject
  public interface NestedInterface {
  }
}
