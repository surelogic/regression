package threadSafe;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class RealClass {
  @ThreadSafe
  public class NestedClass {
    
  }
}
