package containable;

import com.surelogic.Containable;

@Containable
public class RealClass {
  @Containable
  public class NestedClass {
    
  }
}
