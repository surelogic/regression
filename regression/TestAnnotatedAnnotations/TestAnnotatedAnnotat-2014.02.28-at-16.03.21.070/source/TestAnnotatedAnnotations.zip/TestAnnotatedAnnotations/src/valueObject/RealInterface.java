package valueObject;

import com.surelogic.ValueObject;

@ValueObject
public interface RealInterface {
  @ValueObject
  public interface NestedInterface {
  }
}
