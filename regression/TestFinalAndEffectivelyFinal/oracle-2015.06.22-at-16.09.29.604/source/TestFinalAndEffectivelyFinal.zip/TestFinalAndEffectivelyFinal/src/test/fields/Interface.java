package test.fields;

public interface Interface {
  static int f1 = 0;
  static final int f2 = 1;
  
  static String f3 = "abc";
  static final String f4 = "def";
}
