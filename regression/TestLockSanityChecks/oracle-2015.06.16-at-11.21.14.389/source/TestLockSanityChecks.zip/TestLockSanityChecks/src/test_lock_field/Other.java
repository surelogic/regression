package test_lock_field;

public class Other {
  protected static final Object staticField = new Object();
  protected final Object otherField = new Object();
}
