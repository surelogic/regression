package test_lock_field;

public class D extends C {
  final Object fieldFromD = new Object();
  Object badFieldFromD = new Object();
}
