package testDeps2;

import com.surelogic.RequiresLock;

import testDeps.Dependent;

public class Dependent2 extends Dependent {
	@RequiresLock("L") 
	@Override
	protected void foo() {
		// Nothing to do		
	}
}
