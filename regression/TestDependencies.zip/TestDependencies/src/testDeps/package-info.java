/** 
 * Commenting this out should cause all the classes in testDeps to be reprocessed
 */
@Promise("@ThreadSafe for *")
package testDeps;

import com.surelogic.*;