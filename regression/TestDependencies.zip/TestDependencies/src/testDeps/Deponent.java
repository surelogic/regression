package testDeps;

import com.surelogic.*;

@RegionLock("L is this protects Instance")
public class Deponent {

}
