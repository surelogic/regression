package test;

import com.surelogic.AnnotationBounds;
import com.surelogic.Immutable;

@Immutable
@AnnotationBounds(immutable="T")
public class Immut<T> {
  // do nothing
}
