package constructors;

import com.surelogic.Utility;

@Utility
public final class ConstructorHasArgs {
  private ConstructorHasArgs(final int a) {
    super();
  }
}
