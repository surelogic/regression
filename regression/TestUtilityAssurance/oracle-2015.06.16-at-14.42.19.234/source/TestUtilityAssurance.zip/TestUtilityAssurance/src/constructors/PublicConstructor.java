package constructors;

import com.surelogic.Utility;

@Utility
public final class PublicConstructor {
  public PublicConstructor() {
    super();
  }
}
