package test;

import com.surelogic.Utility;

@Utility
public final class Implements2 implements I, J {
  private Implements2() {
    super();
  }
}
