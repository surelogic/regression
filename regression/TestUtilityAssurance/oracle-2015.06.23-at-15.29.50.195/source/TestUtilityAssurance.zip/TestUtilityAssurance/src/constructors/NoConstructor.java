package constructors;

import com.surelogic.Utility;

@Utility
public final class NoConstructor {
  // implicit "public NoConstructor() { super(); }"
}
