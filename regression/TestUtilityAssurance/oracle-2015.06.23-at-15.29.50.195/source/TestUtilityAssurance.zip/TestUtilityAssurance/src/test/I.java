package test;

public interface I {

}
