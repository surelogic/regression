package test;

import com.surelogic.Utility;

@Utility
public final class Public {
  private Public() {
    super();
  }
}
