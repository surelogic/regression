package test;

import com.surelogic.Utility;

@Utility
public final class Implements1 implements I {
  private Implements1() {
    super();
  }
}
