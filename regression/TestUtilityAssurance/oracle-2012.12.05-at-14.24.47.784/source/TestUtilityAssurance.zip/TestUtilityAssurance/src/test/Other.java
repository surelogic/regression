package test;

public class Other {
  public Other() {
    super();
  }
}
