package test;

import com.surelogic.Utility;

@Utility
public class NotFinal {
  private NotFinal() {
    super();
  }
}
