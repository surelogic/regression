package constructors;

import com.surelogic.Utility;

@Utility
public final class PrivateConstructor {
  private PrivateConstructor() {
    super();
  }
}
