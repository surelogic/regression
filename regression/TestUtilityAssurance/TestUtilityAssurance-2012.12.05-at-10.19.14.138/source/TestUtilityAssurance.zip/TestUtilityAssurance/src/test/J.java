package test;

public interface J {

}
