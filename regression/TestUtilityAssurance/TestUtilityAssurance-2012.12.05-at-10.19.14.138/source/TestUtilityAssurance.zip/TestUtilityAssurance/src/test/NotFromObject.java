package test;

import com.surelogic.Utility;

@Utility
public final class NotFromObject extends Other {
  private NotFromObject() {
    super();
  }
}
