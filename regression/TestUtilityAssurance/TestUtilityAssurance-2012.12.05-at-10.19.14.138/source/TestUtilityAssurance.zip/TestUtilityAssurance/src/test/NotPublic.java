package test;

import com.surelogic.Utility;

@Utility
final class NotPublic {
  private NotPublic() {
    super();
  }
}
