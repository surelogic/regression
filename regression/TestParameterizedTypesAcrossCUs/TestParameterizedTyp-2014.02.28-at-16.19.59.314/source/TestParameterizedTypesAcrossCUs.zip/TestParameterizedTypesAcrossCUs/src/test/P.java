package test;

import com.surelogic.AnnotationBounds;

@AnnotationBounds(immutable="X", valueObject="Y")
public class P<X, Y> {
  // empty
}
