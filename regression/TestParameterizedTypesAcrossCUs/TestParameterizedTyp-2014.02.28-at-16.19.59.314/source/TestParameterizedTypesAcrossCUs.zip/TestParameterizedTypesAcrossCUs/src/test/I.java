package test;

import com.surelogic.Immutable;

@Immutable
public class I {
  // empty
}
