package com.surelogic.jsure.planetbaron.game;

import com.surelogic.ThreadSafe;
import com.surelogic.Unique;

/**
 * The abstract base class for things which send update reports from the server
 * to clients. This class is intended to be extended.
 * 
 * @author T.J. Halloran
 */
@ThreadSafe
public abstract class Reporter extends Thing implements TurnMutable {
	@Unique("return")
	Reporter(GameMap map) {
		super(map);
	}

	/**
	 * <code>true</code> if this object has indicated, via a call to
	 * {@link #sendReport()}, that the object needs to send a server update
	 * report for this game turn, <code>false</code> otherwise.
	 */
	private boolean f_sendReport_thisTurn = false;

	/**
	 * <code>true</code> if this object has indicated, via a call to
	 * {@link #sendReport()}, that the object needs to send a server update
	 * report for the last game turn, <code>false</code> otherwise. Essentially,
	 * the value of {@link #f_sendReport_thisTurn} is copied into this field
	 * when {@link #doTurn()} is invoked during a turn.
	 */
	private boolean f_sendReport_lastTurn = false;

	/**
	 * Overriding subclasses must ensure they invoke this method. For example,
	 * via <code>super.doTurn()</code>.
	 * <p>
	 * This method obtains a write lock on {@link Thing#f_lock}.
	 */
	public void doTurn() {
		f_lock.writeLock().lock();
		try {
			f_sendReport_lastTurn = f_sendReport_thisTurn;
			f_sendReport_thisTurn = false;
		} finally {
			f_lock.writeLock().unlock();
		}
	}

	/**
	 * Indicates that a server update report about this object needs to be sent
	 * by the game server to clients at the end of this turn. This method should
	 * be invoked <i>before</i> {@link #doTurn()} has been invoked on this
	 * object for the turn (it may be called within the {@link #doTurn()}
	 * defined by a subclass as long as <code>super.doTurn()</code> has not yet
	 * been invoked).
	 * <p>
	 * This method must be called each turn that an update report needs to be
	 * send about this object.
	 * <p>
	 * This method obtains a write lock on {@link Thing#f_lock}.
	 */
	public final void sendReport() {
		f_lock.writeLock().lock();
		try {
			f_sendReport_thisTurn = true;
		} finally {
			f_lock.writeLock().unlock();
		}
	}

	/**
	 * Returns <code>true</code> if this object needs to send a server update
	 * report, <code>false</code> if it does not. This method should only be
	 * invoked <i>after</i> {@link #doTurn()} has been invoked on this object
	 * for the turn. The result of this method remains stable until
	 * {@link #doTurn()} is invoked during the next turn.
	 * <p>
	 * This method obtains a read lock on {@link Thing#f_lock}.
	 * 
	 * @return <code>true</code> if this object needs to send a server update
	 *         report, <code>false</code> if it does not.
	 */
	public final boolean isSendingReport() {
		f_lock.readLock().lock();
		try {
			return f_sendReport_lastTurn;
		} finally {
			f_lock.readLock().unlock();
		}
	}
}
