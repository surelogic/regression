package com.surelogic.jsure.planetbaron.protocol;

public abstract class ServerCommand extends ASTNode {
}
