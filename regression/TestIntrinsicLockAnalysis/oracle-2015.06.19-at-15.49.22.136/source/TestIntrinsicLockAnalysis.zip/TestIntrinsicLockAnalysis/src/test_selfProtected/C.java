package test_selfProtected;

/**
 * Says nothing about being "self protected" (so it isn't)
 */
public class C {
  public void m() {
    // do nothing
  }
}
