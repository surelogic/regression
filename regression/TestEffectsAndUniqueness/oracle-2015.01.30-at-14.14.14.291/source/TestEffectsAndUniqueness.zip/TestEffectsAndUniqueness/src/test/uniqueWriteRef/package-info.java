/**
 * Test that unique write fields are aggregated via the different forms of the
 * Unique and UniqueInRegion annotations.  SHould behave the same as regular
 * unique fields.
 */
package test.uniqueWriteRef;
