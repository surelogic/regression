/**
 * Test that unique fields are aggregated via the different forms of the
 * Unique and UniqueInRegion annotations.
 */
package test.uniqueRef;
