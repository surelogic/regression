/**
 * Test that borrowed fields are aggregated via the different forms of the
 * Borrowed and BorrowedInRegion annotations.
 */
package test.borrowedField;
