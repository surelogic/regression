/**
 * Test that borrowed read only fields cannot have write effects.
 */
package test.borrowedReadOnlyField.indirect;
