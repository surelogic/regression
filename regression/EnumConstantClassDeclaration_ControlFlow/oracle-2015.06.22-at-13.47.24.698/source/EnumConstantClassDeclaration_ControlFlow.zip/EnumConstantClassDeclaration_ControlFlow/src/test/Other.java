package test;

public class Other {
  public Other(final Object o) {
    super();
  }
}
