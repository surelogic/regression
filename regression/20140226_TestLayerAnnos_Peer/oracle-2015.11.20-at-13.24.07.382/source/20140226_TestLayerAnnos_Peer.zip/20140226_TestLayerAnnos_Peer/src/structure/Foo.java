package structure;

public class Foo {

  public static void good() {
    // TODO Auto-generated method stub
    
  }

  public static void bad() {
    // TODO Auto-generated method stub
    
  }

}
