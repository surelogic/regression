@Promise("@InLayer(edu.afit.csce593.smallworld.textui.{CONSOLE_UI, SWING_UI})")
package edu.afit.csce593.smallworld.textui.parser;

import com.surelogic.*;