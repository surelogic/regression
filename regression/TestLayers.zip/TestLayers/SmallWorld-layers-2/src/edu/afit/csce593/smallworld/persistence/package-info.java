@Promise("@InLayer(edu.afit.csce593.smallworld.PERSISTENCE)")
package edu.afit.csce593.smallworld.persistence;

import com.surelogic.*;