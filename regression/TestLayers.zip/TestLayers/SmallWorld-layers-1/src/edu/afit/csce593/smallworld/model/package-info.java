@Promise("@MayReferTo(java.util)")
package edu.afit.csce593.smallworld.model;

import com.surelogic.*;