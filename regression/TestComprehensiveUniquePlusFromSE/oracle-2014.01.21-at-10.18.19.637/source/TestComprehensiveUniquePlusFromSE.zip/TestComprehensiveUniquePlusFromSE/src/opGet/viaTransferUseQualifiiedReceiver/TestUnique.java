package opGet.viaTransferUseQualifiiedReceiver;

import com.surelogic.Unique;

@SuppressWarnings("unused")
public class TestUnique {
  /* 
   * Cannot declare a qualified receiver to be unique, so this cannot happen.
   */
}
