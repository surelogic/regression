package opLoad.viaTransferUseQualifiedReceiver.outerReceiver;

import com.surelogic.Borrowed;
import com.surelogic.RegionEffects;
import com.surelogic.Unique;

@SuppressWarnings("unused")
public class Test {
	// Cannot happen because it requires assigning to the qualified receiver
}
