package com.surelogic.jsure.planetbaron.client;

import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import com.surelogic.jsure.planetbaron.client.communication.IResponse;
import com.surelogic.jsure.planetbaron.client.communication.ServerProxy;
import com.surelogic.jsure.planetbaron.game.GameMap;
import com.surelogic.jsure.planetbaron.game.Location;
import com.surelogic.jsure.planetbaron.game.Player;
import com.surelogic.jsure.planetbaron.game.Ship;
import com.surelogic.jsure.planetbaron.protocol.*;

/**
 * @author T.J. Halloran
 */
public final class PlayerProxy extends TimerTask {

	private static final long GO_DELAY = 250;

	private final Timer m_goTimer = new Timer("\"go\" timer", true);

	private final ServerProxy m_serverProxy;

	private final String m_playerIdentity;

	private final JFrame m_refreshTarget;

	private int m_Width;

	private int m_Height;

	private double m_Velocity;

	/**
	 * Constructs a player proxy to interact with the given server proxy on
	 * behalf of a specific player. Upon construction this object connects the
	 * player into the game (reporting appropriate errors if something goes
	 * wrong) and initializes the game state using the server's response.
	 * 
	 * @param playerIdentity
	 *            a unique string identifier, checked by the server on connect,
	 *            for the player
	 * @param serverProxy
	 *            the server proxy this player proxy interacts with
	 * @param refreshTarget
	 *            the visual component to refresh if game state is changed
	 */
	public PlayerProxy(String playerIdentity, ServerProxy serverProxy,
			JFrame refreshTarget) {
		m_serverProxy = serverProxy;
		m_playerIdentity = playerIdentity;
		m_refreshTarget = refreshTarget;

		// connect this player into the game so we get a dump of the game state
		Play p = new Play(playerIdentity);
		m_serverProxy.sendCommand(p, new IResponse() {
			public void process(ServerProxy proxy, ServerCommand command,
					ServerResponse response) {
				if (response instanceof GameStateUpdate) {
					processGameStateUpdate((GameStateUpdate) response);
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							m_refreshTarget.getContentPane().repaint();
						}
					});
					notifyPlayerConnectedOK();
					m_goTimer.schedule(PlayerProxy.this, GO_DELAY, GO_DELAY);
				} else if (response instanceof ProtocolError) {
					// something went very wrong
					JOptionPane.showMessageDialog(null,
							((ProtocolError) response).getMessage(),
							"Unable to play as \"" + m_playerIdentity + "\"",
							JOptionPane.ERROR_MESSAGE);
					m_serverProxy.shutdown();
				}
			}
		});
	}

	/**
	 * Informs the server that the ship this player controls wants to move to
	 * the given location.
	 * 
	 * @param l
	 *            the location to move the ship to
	 */
	public void moveShipTo(final Location l) {
		// Check that the move is not a no-op or that we are not already moving
		final Player p = GameMap.getInstance().getPlayer(m_playerIdentity);
		Ship s = GameMap.getInstance().getShip(p);
		if (s.isMoving())
			return; // bail out if we are already moving
		if (s.getLocation().equals(l))
			return; // bail out if move is a no-op

		MoveShip ms = new MoveShip(m_playerIdentity, l);
		m_serverProxy.sendCommand(ms, new IResponse() {
			public void process(ServerProxy proxy, ServerCommand command,
					ServerResponse response) {
				if (response instanceof GameStateUpdate) {
					processGameStateUpdate((GameStateUpdate) response);
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							m_refreshTarget.getContentPane().repaint();
						}
					});
				} else if (response instanceof ProtocolError) {
					// something went very wrong
					JOptionPane.showMessageDialog(null,
							((ProtocolError) response).getMessage(),
							"Unable to move ship \"" + m_playerIdentity
									+ "\" (please report this as a bug)",
							JOptionPane.ERROR_MESSAGE);
					m_serverProxy.shutdown();
				}
			}
		});
	}

	private void processGameStateUpdate(GameStateUpdate report) {
		ResponseVisitor rv = new ResponseVisitor();
		report.accept(rv);
	}

	/**
	 * @return Returns the m_Height.
	 */
	public int getHeight() {
		return m_Height;
	}

	/**
	 * @return Returns the m_Width.
	 */
	public int getWidth() {
		return m_Width;
	}

	/**
	 * @return Returns the m_Velocity.
	 */
	public double getVelocity() {
		return m_Velocity;
	}

	private volatile boolean m_shutdownRequested = false;

	/**
	 * Informs this object that the connection to the server has been
	 * terminated.
	 */
	public void shutdown() {
		m_goTimer.cancel();
		m_shutdownRequested = true;
	}

	/*
	 * GO timer callback action method. Called by our timer to allow this player
	 * to move on to the next turn and not hang the game.
	 */
	public void run() {
		if (!m_shutdownRequested) {
			m_serverProxy.sendCommand(new Go(), new IResponse() {
				public void process(ServerProxy proxy, ServerCommand command,
						ServerResponse response) {
					if (response instanceof GameStateUpdate) {
						processGameStateUpdate((GameStateUpdate) response);
						GameMap.getInstance().endCurrentTurn();
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								m_refreshTarget.getContentPane().repaint();
							}
						});
					} else if (response instanceof ProtocolError) {
						// something went very wrong
						JOptionPane.showMessageDialog(null,
								((ProtocolError) response).getMessage(),
								"GO Command Failed", JOptionPane.ERROR_MESSAGE);
						m_serverProxy.shutdown();
					}
				}
			});
		}
	}

	/**
	 * Returns the identity of the player this proxy represents.
	 * 
	 * @return the identity of the player this proxy represents
	 */
	public String getplayerIdentity() {
		return m_playerIdentity;
	}

	public interface IPlayerListener {
		/**
		 * Invoked when the player this player was created with has been
		 * successfully connected to the game server and the initial game state
		 * download has been completed.
		 */
		void playerConnectedOK();
	}

	private final Set<IPlayerListener> m_playerListeners = new HashSet<IPlayerListener>();

	public void registerPlayerListener(IPlayerListener l) {
		if (l == null)
			throw new IllegalArgumentException("player listener cannot be null");
		m_playerListeners.add(l);
	}

	private void notifyPlayerConnectedOK() {
		for (IPlayerListener l : m_playerListeners) {
			l.playerConnectedOK();
		}
	}
}
