package com.surelogic.jsure.planetbaron.game;

import java.util.HashMap;
import java.util.Map;

import com.surelogic.*;
import com.surelogic.jsure.planetbaron.util.Common;

/**
 * Represents a position on the game map. Instances are obtained using the
 * {@link #getInstance(int, int)} or {@link #getRandomInstance()} methods. Only
 * a single instance exists for each coordinate value, so reference equality is
 * the equivalent to value equality.
 * 
 * @author T.J. Halloran
 */
@ThreadSafe
@Region("private static Location_InstanceMap")
@RegionLock("Location_Lock is lock protects Location_InstanceMap")
public final class Location {

	/**
	 * Protects access to the contents of {@link #f_x2y2Location}.
	 */
	private static final Object lock = new Object();

	@UniqueInRegion("Location_InstanceMap")
	private static final Map<Integer, Map<Integer, Location>> f_x2y2Location = new HashMap<Integer, Map<Integer, Location>>();

	/**
	 * Returns a reference to the specified location.
	 * 
	 * @param x
	 *            the x coordinate.
	 * @param y
	 *            the y coordinate.
	 * @return a reference to the specified location.
	 * @throws IllegalArgumentException
	 *             if the new location is not on the game map.
	 */
	public static Location getInstance(int x, int y) {
		boolean offGameMap = x < 1 || y < 1
				|| x > GameMap.getInstance().getWidth()
				|| y > GameMap.getInstance().getHeight();
		if (offGameMap) {
			throw new IllegalArgumentException("the coordinates (" + x + ","
					+ y + ") are not on the "
					+ GameMap.getInstance().getWidth() + "x"
					+ GameMap.getInstance().getHeight() + " game map");
		}
		/*
		 * Only a single instance exists for each value so we need to look it up
		 */
		Location result;
		synchronized (lock) {
			Map<Integer, Location> y2Location = f_x2y2Location.get(x);
			if (y2Location == null) {
				result = new Location(x, y);
				y2Location = new HashMap<Integer, Location>();
				y2Location.put(y, result);
				f_x2y2Location.put(x, y2Location);
			} else {
				result = y2Location.get(y);
				if (result == null) {
					result = new Location(x, y);
					y2Location.put(y, result);
				}
			}
		}
		return result;
	}

	/**
	 * Returns a reference to a random location on the game map.
	 * 
	 * @return a reference to a random location on the game map.
	 */
	public static Location getRandomInstance() {
		return getInstance(Common.rand.nextInt(Common.LOGICAL_MAP_WIDTH) + 1,
				Common.rand.nextInt(Common.LOGICAL_MAP_HEIGHT) + 1);
	}

	private final int f_x;

	private final int f_y;

	/**
	 * Constructs a new location.
	 * 
	 * @param x
	 *            new x coordinate.
	 * @param y
	 *            new y coordinate.
	 */
	private Location(int x, int y) {
		f_x = x;
		f_y = y;
	}

	/**
	 * Returns the x coordinate of this location.
	 * 
	 * @return the x coordinate of this location.
	 */
	public int getX() {
		return f_x;
	}

	/**
	 * Returns the y coordinate of this location.
	 * 
	 * @return the y coordinate of this location.
	 */
	public int getY() {
		return f_y;
	}

	/**
	 * Computes the distance on game map from this location to the given
	 * location.
	 * 
	 * @param l
	 *            the location to compute the distance to.
	 * @return the distance in game map coordinates.
	 */
	public double distanceTo(Location l) {
		double deltaX = Math.abs(getX() - l.getX());
		double deltaY = Math.abs(getY() - l.getY());
		return Math.sqrt(deltaX * deltaX + deltaY + deltaY);
	}

	@Override
	public String toString() {
		return "(" + f_x + "," + f_y + ")";
	}
}
