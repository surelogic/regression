package test.formals.any;

import com.surelogic.Region;

@Region("public R")
public class Other {

}
