package test.qualifiedThis.any;

import com.surelogic.Region;

@Region("public R")
public class Other {

}
