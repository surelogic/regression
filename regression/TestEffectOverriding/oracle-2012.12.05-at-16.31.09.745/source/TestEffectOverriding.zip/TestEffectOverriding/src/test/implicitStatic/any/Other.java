package test.implicitStatic.any;

import com.surelogic.Region;

@Region("public R")
public class Other {

}
