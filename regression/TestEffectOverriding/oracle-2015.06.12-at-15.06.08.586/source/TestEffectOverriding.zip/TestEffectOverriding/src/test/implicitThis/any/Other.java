package test.implicitThis.any;

import com.surelogic.Region;

@Region("public R")
public class Other {

}
