package test;

import com.surelogic.ThreadSafe;

// GOOD: Extends immutable implementation, can be thread safe
@ThreadSafe
public class ThreadSafe3 extends ImmutableImpl {

}
