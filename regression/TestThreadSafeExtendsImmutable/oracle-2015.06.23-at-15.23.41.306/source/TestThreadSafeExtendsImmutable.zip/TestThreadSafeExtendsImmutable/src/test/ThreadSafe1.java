package test;

import com.surelogic.ThreadSafe;

// BAD: Implements immutable interface, must be immutable
@ThreadSafe
public class ThreadSafe1 implements ImmutableInterface {

}
