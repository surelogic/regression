package test;

import com.surelogic.Immutable;

@Immutable(implementationOnly=true)
public class ImmutableImpl {

}
