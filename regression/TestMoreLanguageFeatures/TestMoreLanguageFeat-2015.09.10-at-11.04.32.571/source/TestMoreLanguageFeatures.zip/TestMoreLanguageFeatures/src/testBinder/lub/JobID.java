package testBinder.lub;

public class JobID extends ID /*implements Comparable<ID>*/ {
	@Override
	public int compareTo(ID o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
