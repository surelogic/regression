package testRewriting;

import java.applet.Applet;

public class TestApplet extends Applet {

}
