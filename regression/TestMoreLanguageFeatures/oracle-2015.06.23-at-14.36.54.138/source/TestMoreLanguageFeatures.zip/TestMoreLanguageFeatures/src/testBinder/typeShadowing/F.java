package testBinder.typeShadowing;

public class F {
	int f;
}
