package testBinder;

public class SingleArcTransition<OPERAND, EVENT> {
	void transition(OPERAND o, EVENT e) {
		
	}
}
