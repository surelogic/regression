package testBinder.mutualImport;

import testBinder.mutualImport.Type1.*;
import javax.lang.model.element.*;

public abstract class Type2 implements Element {

}
