package testBinder.shadowing;

public class TestMethodShadowing {
	void main() {
		Sub.shadow().sub();
	}
}
