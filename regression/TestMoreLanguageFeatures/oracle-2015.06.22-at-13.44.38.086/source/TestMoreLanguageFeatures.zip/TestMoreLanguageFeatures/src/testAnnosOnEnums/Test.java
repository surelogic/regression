package testAnnosOnEnums;

public enum Test {
	@Deprecated
	A,
	@Deprecated
	B
}
