package testBinder;

import com.surelogic.Containable;
import com.surelogic.Unique;

@Containable
public class TestWhen<A, B, C> {

	@Unique("return") public TestWhen(){}

}
