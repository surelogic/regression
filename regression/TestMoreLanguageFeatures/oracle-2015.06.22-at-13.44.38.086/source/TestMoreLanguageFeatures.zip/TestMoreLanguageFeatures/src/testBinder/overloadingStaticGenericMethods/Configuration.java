package testBinder.overloadingStaticGenericMethods;

public class Configuration {

}
