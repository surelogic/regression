package testBinder.localTypeInACE;

public class Outer {
	class Visitor {
		Visitor(boolean foo) {
			// Nothing to do
		}
	}
}
