package testBinder.rawGenerics;

import javax.xml.transform.Result;

public class XmlResultProvider {
	public void provideXml(Result setResult) {
		// TODO Auto-generated method stub
		
	}

}
