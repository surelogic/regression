package testBinder.lub;

public class ID implements Comparable<ID> {
	public int compareTo(ID o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
