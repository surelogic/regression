package testBinder.mutualImport;

import testBinder.mutualImport.Type2.*;

public class Type1 implements Cloneable {

}
