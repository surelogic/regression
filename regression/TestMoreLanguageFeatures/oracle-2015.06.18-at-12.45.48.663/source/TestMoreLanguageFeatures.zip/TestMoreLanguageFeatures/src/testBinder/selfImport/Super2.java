package testBinder.selfImport;

public class Super2 {

}
