package testBinder;

public class MultipleArcTransition<OPERAND, EVENT, STATE> {
	STATE transition(OPERAND o, EVENT e) {
		return null;
	}
}
