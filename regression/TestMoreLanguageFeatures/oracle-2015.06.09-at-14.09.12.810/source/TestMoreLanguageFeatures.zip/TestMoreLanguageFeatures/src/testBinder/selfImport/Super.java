package testBinder.selfImport;

public class Super {

}
