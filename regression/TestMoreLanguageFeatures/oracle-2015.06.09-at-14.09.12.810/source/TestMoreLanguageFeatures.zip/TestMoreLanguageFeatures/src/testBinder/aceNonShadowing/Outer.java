package testBinder.aceNonShadowing;

public class Outer {
	public interface
	passwordDetails
	{		
	}
}
