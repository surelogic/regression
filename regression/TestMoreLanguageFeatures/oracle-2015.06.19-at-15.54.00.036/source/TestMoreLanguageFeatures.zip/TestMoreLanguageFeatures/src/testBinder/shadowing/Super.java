package testBinder.shadowing;

public class Super {
	static Super shadow() {
		return null;
	}
}
