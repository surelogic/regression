package testBinder.rawGenerics;

public abstract class AbstractJdbc4SqlXmlValue extends SqlXmlValue {

}
