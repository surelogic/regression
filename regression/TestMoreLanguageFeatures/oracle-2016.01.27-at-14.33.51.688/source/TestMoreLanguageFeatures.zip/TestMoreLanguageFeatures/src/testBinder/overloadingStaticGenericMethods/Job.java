package testBinder.overloadingStaticGenericMethods;

public class Job {

	public Configuration getConfiguration() {
		// TODO Auto-generated method stub
		return null;
	}

}
