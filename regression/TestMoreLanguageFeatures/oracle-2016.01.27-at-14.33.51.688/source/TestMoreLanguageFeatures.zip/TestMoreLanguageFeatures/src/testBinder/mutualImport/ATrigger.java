package testBinder.mutualImport;

import testBinder.selfImport.*;
import testBinder.mutualImport.Type1.*;

public class ATrigger extends Outer {

}
