package testBinder;

public class Graph {

	public class Node {

		public void addEdge(Node toNode, String string) {
			// TODO Auto-generated method stub
			
		}

	}

	public Graph(String name) {
		// TODO Auto-generated constructor stub
	}

	public Graph.Node getNode(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
