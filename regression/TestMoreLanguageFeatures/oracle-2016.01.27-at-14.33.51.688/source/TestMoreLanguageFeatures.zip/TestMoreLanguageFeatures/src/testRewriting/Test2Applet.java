package testRewriting;

public class Test2Applet extends TestApplet {

}
