package test;

public class B extends A {
  public B() {
    super();
  }
}
