package test.typevars;

public class Parent {
  // empty
}
