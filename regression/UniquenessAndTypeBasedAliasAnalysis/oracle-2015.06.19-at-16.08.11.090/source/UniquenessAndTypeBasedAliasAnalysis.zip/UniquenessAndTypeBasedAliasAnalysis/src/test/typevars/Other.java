package test.typevars;

public interface Other {
  // empty
}
