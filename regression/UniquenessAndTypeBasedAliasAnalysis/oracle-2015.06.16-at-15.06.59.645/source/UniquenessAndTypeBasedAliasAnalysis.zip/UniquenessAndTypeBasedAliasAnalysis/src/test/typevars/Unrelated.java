package test.typevars;


/**
 * Class that is not assignable to WithUnique, and vice versa.
 *
 */
public class Unrelated {
  // empty
}
