package testTrivialMessages.testThreadSafe;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class AppliesToBothHasBoth {
	public static int staticF;
	public int instanceF;
}
