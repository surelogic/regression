package helpers;

public class MutClass {
  // empty
}
