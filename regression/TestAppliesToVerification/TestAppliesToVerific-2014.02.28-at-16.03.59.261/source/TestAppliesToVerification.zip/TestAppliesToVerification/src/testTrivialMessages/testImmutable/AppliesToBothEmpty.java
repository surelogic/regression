package testTrivialMessages.testImmutable;

import com.surelogic.Immutable;

@Immutable
public class AppliesToBothEmpty {
}
