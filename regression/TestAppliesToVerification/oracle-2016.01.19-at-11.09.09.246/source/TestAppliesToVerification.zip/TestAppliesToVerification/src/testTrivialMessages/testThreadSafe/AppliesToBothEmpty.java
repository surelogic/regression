package testTrivialMessages.testThreadSafe;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class AppliesToBothEmpty {
}
