package testTrivialMessages.testImmutable;

import com.surelogic.Immutable;

@Immutable
public interface IAppliesToBothEmpty {
}
