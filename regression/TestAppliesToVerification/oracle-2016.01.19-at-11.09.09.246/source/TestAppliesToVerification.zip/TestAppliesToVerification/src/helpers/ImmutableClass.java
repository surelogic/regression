package helpers;

import com.surelogic.Immutable;

@Immutable
public class ImmutableClass {
  // empty
}
