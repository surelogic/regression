package testTrivialMessages.testImmutable;

import com.surelogic.Immutable;

@Immutable
public interface IAppliesToBothHasStatic {
	public static int staticF = 0;
}
