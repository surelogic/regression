package helpers;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class TS {
  // empty
}
