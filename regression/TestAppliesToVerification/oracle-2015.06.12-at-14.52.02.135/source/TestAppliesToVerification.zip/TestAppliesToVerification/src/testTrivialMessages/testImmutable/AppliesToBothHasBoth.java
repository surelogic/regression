package testTrivialMessages.testImmutable;

import com.surelogic.Immutable;

@Immutable
public class AppliesToBothHasBoth {
	public static int staticF;
	public int instanceF;
}
