package testTrivialMessages.testThreadSafe;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class AppliesToBothHasInstance {
	public int instanceF;
}
