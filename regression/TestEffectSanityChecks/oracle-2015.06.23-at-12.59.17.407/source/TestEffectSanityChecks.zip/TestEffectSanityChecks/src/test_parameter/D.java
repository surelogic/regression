package test_parameter;

import com.surelogic.Region;

@Region("public RegionFromD")
public class D {

}
