package test;

import com.surelogic.NonNull;
import com.surelogic.Nullable;

public class Test {
  private Other unannotated;
  private @Nullable Other nullable;
  private @NonNull Other nonNull = null;
  
  private Test t1 = this;
  private @Nullable Test t2 = this;
  private @NonNull Test t3 = this;
  
  public Test() {
    unannotated = null; // good
    nullable = null; // good
    nonNull = null; // bad

    t1 = this; // bad
    t2 = this; // bad
    t3 = this; // bad
    
    // Don't care about locals
    @NonNull Other o = null; // not checked by type checker
    Test z = null; // not checked by type checker
    z = this; // not checked by type checker
  }
}

class Other {
  public Other() {
    super();
  }
}