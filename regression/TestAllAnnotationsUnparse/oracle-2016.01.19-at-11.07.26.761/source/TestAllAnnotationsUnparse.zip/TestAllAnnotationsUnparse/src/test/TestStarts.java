package test;

import com.surelogic.*;

public class TestStarts {
	@Starts("nothing")
	void foo() {
		
	}
}
