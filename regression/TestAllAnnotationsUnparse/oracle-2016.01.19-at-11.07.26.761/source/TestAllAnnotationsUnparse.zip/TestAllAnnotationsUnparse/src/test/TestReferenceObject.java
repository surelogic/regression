package test;

import com.surelogic.ReferenceObject;

@ReferenceObject
public class TestReferenceObject {

}
