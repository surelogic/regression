package test;

import com.surelogic.Singleton;

@Singleton
public class TestSingleton {

}
