package test;

import com.surelogic.Mutable;

public class TestMutable {
	@Mutable
	class Inner {
		
	}
}
