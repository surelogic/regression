package test;

import com.surelogic.Raw;

public class TestRaw {	
	/* TODO
	@Raw
	TestRaw() {
	}
	
	@Raw
	void foo(@Raw Object f) {
		
	}
	*/
}
