package test;

import com.surelogic.ValueObject;

@ValueObject
public class TestValueObject {

}
