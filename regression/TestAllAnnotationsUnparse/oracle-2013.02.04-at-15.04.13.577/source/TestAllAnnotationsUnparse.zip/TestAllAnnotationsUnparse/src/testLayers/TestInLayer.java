package testLayers;

import com.surelogic.InLayer;

@InLayer("testLayers.MODEL")
public class TestInLayer {

}
