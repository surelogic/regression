package test;

import com.surelogic.MustInvokeOnOverride;

public class TestMustInvokeOnOverride {
	@MustInvokeOnOverride
	void foo() {
		
	}
}
