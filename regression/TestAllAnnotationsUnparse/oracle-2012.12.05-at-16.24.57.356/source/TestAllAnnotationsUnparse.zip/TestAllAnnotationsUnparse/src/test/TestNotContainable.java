package test;

import com.surelogic.NotContainable;

public class TestNotContainable {
	@NotContainable
	class Inner {
		
	}
}
