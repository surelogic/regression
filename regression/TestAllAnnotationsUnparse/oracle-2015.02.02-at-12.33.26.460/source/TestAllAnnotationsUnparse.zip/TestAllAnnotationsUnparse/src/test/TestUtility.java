package test;

import com.surelogic.Utility;

@Utility
public class TestUtility {

}
