package test;

import com.surelogic.NotThreadSafe;

public class TestNotThreadSafe {
	@NotThreadSafe
	class Inner {
		
	}
}
