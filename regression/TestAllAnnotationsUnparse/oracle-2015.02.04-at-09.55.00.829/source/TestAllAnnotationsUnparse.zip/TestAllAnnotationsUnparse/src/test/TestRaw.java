package test;

import com.surelogic.Initialized;

public class TestRaw {	
	/* TODO
	@Initialized
	TestRaw() {
	}
	
	@Initialized
	void foo(@Initialized(through="Object") Object f) {
		
	}
	*/
}
