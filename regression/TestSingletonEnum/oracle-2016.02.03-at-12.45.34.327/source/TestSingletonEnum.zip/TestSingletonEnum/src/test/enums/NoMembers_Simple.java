package test.enums;

import com.surelogic.Singleton;

@Singleton
public enum NoMembers_Simple {
  // no members
}
