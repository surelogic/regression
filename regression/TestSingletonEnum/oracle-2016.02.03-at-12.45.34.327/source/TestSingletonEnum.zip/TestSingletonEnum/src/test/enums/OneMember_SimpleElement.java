package test.enums;

import com.surelogic.Singleton;

@Singleton
public enum OneMember_SimpleElement {
  INSTANCE;
}
