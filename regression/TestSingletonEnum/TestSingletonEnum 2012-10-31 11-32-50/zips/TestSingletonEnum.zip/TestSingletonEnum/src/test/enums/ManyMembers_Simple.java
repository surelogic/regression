package test.enums;

import com.surelogic.Singleton;

@Singleton
public enum ManyMembers_Simple {
  INSTANCE,
  EXTRA;
}
