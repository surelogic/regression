package valObject;

import com.surelogic.ValueObject;

// Illegal
@ValueObject
public enum Direct {
	A, B, C;
}
