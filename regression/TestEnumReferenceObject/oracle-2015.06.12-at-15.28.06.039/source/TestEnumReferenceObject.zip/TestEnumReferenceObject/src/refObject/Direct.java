package refObject;

import com.surelogic.ReferenceObject;

// Illegal
@ReferenceObject
public enum Direct {
	A, B, C;
}
