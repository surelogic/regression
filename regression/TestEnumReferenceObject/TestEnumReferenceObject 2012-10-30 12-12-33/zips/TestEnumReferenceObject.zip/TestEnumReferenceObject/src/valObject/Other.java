package valObject;

public interface Other {

}
