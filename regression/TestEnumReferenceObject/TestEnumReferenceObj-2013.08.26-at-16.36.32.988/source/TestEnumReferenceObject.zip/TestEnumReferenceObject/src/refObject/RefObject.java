package refObject;

import com.surelogic.ReferenceObject;

@ReferenceObject
public interface RefObject {
	// empty
}
