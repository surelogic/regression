package refObject;

public interface Other {

}
