package valObject;

import com.surelogic.ValueObject;

@ValueObject
public interface ValObject {
	// empty
}
