package testTypeRefs;

import com.surelogic.*;

@Region("public Root")
//1. Creates a warning in nullifyRoot() below
//@RegionLock("L is this protects Root")
public class HasALockDecl {
	@InRegion("Root")
	Object root;

	//2. Creates a warning in UseType
	//@RequiresLock("L")
	public void nullifyRoot() {
		root = null;
	}
}
