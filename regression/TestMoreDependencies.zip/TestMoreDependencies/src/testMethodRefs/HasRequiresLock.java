package testMethodRefs;

import testTypeRefs.HasALockDecl;

import com.surelogic.*;

public class HasRequiresLock extends HasALockDecl {
	// Can't type-qualify an instance lock
	// @RequiresLock("testTypeRefs.HasALockDecl:L")
	
	//5. Creates a warning in UseMethod
	//@RequiresLock("L")
	public void foo() {				
	}
}
