package anotherPackage;

import testTypeRefs.HasALockDecl;

public class UseType {
	HasALockDecl hald;
	
	void bar() {
		hald.nullifyRoot();
	}
}
