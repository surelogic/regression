package testFieldRefs;

import com.surelogic.*;
import testTypeRefs.HasALockDecl;

//3. Does nothing for now
//@Region("public Field extends Root")
public class HasARegionDecl extends HasALockDecl {
	//4. Creates a warning in UseField()
	//@InRegion("Field")
	protected Object field;
}
