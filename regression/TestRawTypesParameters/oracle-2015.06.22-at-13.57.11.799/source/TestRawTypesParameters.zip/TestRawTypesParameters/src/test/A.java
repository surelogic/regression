package test;

public class A {
  public A() {
    super();
  }
}
