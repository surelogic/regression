package test;

public class Test {
	void f(byte b) {		
	}
	
	void g() {
		f((byte) (5+5));
	}
}
