package test;

class NonContainableClass {}