package test;

import com.surelogic.Containable;
import com.surelogic.Promise;

@Containable
@Promise("@Unique(return) for new()")
class ContainableClass {}