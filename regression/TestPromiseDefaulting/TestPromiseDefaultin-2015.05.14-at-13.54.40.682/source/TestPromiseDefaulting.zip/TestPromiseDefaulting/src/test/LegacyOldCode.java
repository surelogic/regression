package test;

import com.surelogic.*;

@Promise("@Nullable")
public class LegacyOldCode {
  @NonNull
  public String getLegacyValue() { 
	  return "";
  }
}
