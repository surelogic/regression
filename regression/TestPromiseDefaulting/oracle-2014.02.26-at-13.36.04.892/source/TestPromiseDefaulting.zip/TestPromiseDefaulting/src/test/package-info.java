@Promises({
	@Promise("@NonNull"),
	@Promise("@RegionEffects(none) for new(**)")
})
package test;

import com.surelogic.*;