package vouchThreadSafe;

import com.surelogic.NotThreadSafe;

@NotThreadSafe
public class NotThreadSafeClass {
	// bogus
}
