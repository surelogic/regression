package vouchThreadSafe;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class ThreadSafeClass {
	// bogus
}
