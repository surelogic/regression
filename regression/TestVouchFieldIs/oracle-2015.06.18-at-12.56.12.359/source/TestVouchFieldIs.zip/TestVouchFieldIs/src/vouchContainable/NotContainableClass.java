package vouchContainable;

import com.surelogic.NotContainable;;

@NotContainable
public class NotContainableClass {
	// bogus
}
