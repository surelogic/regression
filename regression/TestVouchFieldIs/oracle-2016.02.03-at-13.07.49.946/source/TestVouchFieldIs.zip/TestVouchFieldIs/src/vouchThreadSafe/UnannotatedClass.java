package vouchThreadSafe;

public class UnannotatedClass {
	// bogus
}
