package vouchContainable;

import com.surelogic.Containable;

@Containable
public class ContainableClass {
	// bogus
}
