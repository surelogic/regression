package vouchImmutable;

public class UnannotatedClass {
	// bogus
}
