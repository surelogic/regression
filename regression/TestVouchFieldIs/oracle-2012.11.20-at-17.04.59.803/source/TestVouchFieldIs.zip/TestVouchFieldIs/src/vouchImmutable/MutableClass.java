package vouchImmutable;

import com.surelogic.Mutable;;

@Mutable
public class MutableClass {
	// bogus
}
