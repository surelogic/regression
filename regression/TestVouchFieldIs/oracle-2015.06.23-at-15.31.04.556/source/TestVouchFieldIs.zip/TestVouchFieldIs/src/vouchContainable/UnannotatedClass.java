package vouchContainable;

public class UnannotatedClass {
	// bogus
}
