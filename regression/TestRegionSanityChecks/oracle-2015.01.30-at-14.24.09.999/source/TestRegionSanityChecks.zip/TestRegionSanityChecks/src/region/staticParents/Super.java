package region.staticParents;

import com.surelogic.Region;
import com.surelogic.Regions;

@Regions({
  @Region("static SuperStatic"),
  @Region("SuperInstance")
})
public class Super {
}
