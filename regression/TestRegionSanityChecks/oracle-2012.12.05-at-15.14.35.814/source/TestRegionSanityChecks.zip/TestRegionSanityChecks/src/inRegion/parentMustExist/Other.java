package inRegion.parentMustExist;

import com.surelogic.Region;

@Region("UnrelatedRegion")
public class Other {

}
